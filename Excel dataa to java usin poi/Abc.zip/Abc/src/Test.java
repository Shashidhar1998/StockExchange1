import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	
		FileInputStream file = new FileInputStream(new File("C:\\Users\\765477\\Desktop\\Book1.xlsx")); 
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(file); 
		XSSFSheet sheet = workbook.getSheetAt(0); 
        Row row;
        for(int i=1; i<=sheet.getLastRowNum(); i++){  //points to the starting of excel i.e excel first row
            row = (Row) sheet.getRow(i);  //sheet number
            
            
	            String id;
				if( row.getCell(0)==null) { id = "0"; }
	            else id= row.getCell(0).toString();

                   String name;
				if( row.getCell(1)==null) { name = "null";}  //suppose excel cell is empty then its set to 0 the variable
                   else name = row.getCell(1).toString();   //else copies cell data to name variable

                   String address;
				if( row.getCell(2)==null) { address = "null";   }
                   else  address   = row.getCell(2).toString();
	
	   System.out.println("Id :"+id+"     Name :"+name+"    address :"+address);

	
	    	
        }
		file.close();

	}

}
