package com.example.StockMarketCharting.Services;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarketCharting.Models.IpoPlanned;

public interface IpoService extends CrudRepository<IpoPlanned, Long>{

}
