package com.example.StockMarketCharting.Controllers;

public class AdminController {

}
