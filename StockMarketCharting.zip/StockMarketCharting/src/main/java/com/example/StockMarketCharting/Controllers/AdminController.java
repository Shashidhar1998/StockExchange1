package com.example.StockMarketCharting.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.StockMarketCharting.Models.Company;
import com.example.StockMarketCharting.Services.CompanyService;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/StockExchange")
public class AdminController {
	
	@Autowired
	CompanyService adminservice;
	
	@GetMapping("/companies")
	public List<Company> getAllCustomers() {
		System.out.println("Get all Customers...");

		List<Company> customers = new ArrayList<>();
		adminservice.findAll().forEach(customers::add);

		return customers;
	}

}
