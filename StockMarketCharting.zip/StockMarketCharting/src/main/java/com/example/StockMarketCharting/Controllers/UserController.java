package com.example.StockMarketCharting.Controllers;

public class UserController {

}
