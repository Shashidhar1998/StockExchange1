package com.example.StockMarketCharting.Models;

public class StockPriceData {

}
