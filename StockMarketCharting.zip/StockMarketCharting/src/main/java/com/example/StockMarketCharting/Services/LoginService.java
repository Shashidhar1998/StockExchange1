package com.example.StockMarketCharting.Services;

public class LoginService {

}
