package com.example.StockMarketCharting.Services;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarketCharting.Models.User;

public interface LoginService extends CrudRepository<User, Long>{

}
