package Models;

public class User {
private String username,password,email,usertype,confirmed;
private int id,mobile;
public String getUsername() {
	return username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getUsertype() {
	return usertype;
}
public void setUsertype(String usertype) {
	this.usertype = usertype;
}
public String getConfirmed() {
	return confirmed;
}
public void setConfirmed(String confirmed) {
	this.confirmed = confirmed;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getMobile() {
	return mobile;
}
public void setMobile(int mobile) {
	this.mobile = mobile;
}
public void setUsername(String username) {
	this.username = username;
}

}
