package Models;

public class Company {

}
