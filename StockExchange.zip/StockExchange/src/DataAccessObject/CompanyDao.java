package DataAccessObject;

public class CompanyDao {



	public String validateinDatabase(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
